Regarding the Borland C++ examples in Chapter 12: 

Look in the LongRand\MASM and ReadSec\MASM folders for the MASM version of the asm files.

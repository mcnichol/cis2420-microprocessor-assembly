// findArr.cpp

// Implements a linear search of an array of
// long integers.

#include "findarr.h"

bool FindArray( long searchVal, long array[], long count )
{
	for(int i = 0; i < count; i++)
		array[i] *= searchVal;

  return false;
}
